# Software Studio 2023 Spring
## Assignment 01 Web Canvas


### Scoring

| **Basic components**                             | **Score** | **Check** |
| :----------------------------------------------- | :-------: | :-------: |
| Basic control tools                              | 30%       | Y         |
| Text input                                       | 10%       | Y         |
| Cursor icon                                      | 10%       | Y         |
| Refresh button                                   | 5%       | Y         |

| **Advanced tools**                               | **Score** | **Check** |
| :----------------------------------------------- | :-------: | :-------: |
| Different brush shapes                           | 15%       | Y         |
| Un/Re-do button                                  | 10%       | Y         |
| Image tool                                       | 5%        | Y         |
| Download                                         | 5%        | Y         |

| **Other useful widgets**                         | **Score** | **Check** |
| :----------------------------------------------- | :-------: | :-------: |
| Name of widgets                                  | 1~5%     | Y         |


---

### How to use 

    一進入網頁就會看到左邊為畫布，右邊為工具列，接下來會一一介紹所有功能與操作方式：
    1. 調色盤：
        直接點擊想要使用的顏色即可，適用工具：pen, text, 
        circle, rectangle, triangle
    2. 尺寸滑桿：
        皆為向右放大，向左縮小。
        * Draw是調整pen, eraser, circle, rectangle, triangle, rainbow的筆觸大小
        * Text是調整text打字工具的字體大小
    3. 字體選擇：
        位在'Select Font'下方的下拉式工具列可供字體選擇
    4. Pen：
        此為畫筆功能，初始工具即為畫筆。點取工具列中的'Pen'後，可以在尺寸滑桿中調整筆刷大小，並選定顏色，就可以在畫布上作畫了。
    5. Eraser：
        此為橡皮擦功能，點取工具列中的'Eraser'後，可以在尺寸滑桿中調整大小，即可擦拭畫布上的所有東西。
    6. Text：
        此為打字功能，點取工具列的'Text'後，可以在字體專屬的尺寸滑桿中調整大小，並選取字體與顏色，在點擊畫布後，會出現一文字方塊，此時即可打字，在按下Enter鍵後，所打的文字就會出現在畫布上。
    7. Circle：
        此為畫圓功能，點取工具列的'Circle'後，可以在畫布上一處按下滑鼠，此固定為圓心，向外拖曳滑鼠可以決定想要的圓圈大小，鬆開滑鼠即會把圓畫在畫布上。
    8. Rectangle：
        此為畫矩形功能，點取工具列的'Rectangle'後，可以在畫布上一處按下滑鼠，此固定為矩形其中一角，向外拖曳滑鼠可以決定矩形大小，鬆開滑鼠即會把矩形畫在畫布上。
    9. Triangle：
        此為畫三角形功能，點取工具列的'Triangle'後，可以在畫布上一處按下滑鼠，此固定為等腰三角形的頂角，向外拖曳滑鼠可以決定三角形大小，鬆開滑鼠即會把三角形畫在畫布上。
    10. Reset：
        點取工具列的'Reset'即會重制畫布
    11. Undo：
        點取工具列的'Undo'即會回前一步
    12. Redo：
        點取工具列的'Redo'即會到後一步
    13. Image：
        點取工具列的'Image'後，再於畫布上點擊一下，即會跳出檔案總管，此時可以選取圖片，選定後按下開啟，再點選畫布上任一處為圖片放置處。
    14. Download：
        點取工具列的'Download'後，即會下載現在的畫布(png檔)
    15. Rainbow：
        點取工具列的'Rainbow'後，可以在畫布上以彩虹筆作畫，其顏色會不斷改變呈類似彩虹貌。
        


### Bonus Function description

    Rainbow：
    點取工具列的'Rainbow'後，可以在畫布上以彩虹筆作畫，其顏色會不斷改變呈類似彩虹貌。

### Web page link

    your web page URL.

### Others (Optional)

    Anything you want to say to TAs.

<style>
table th{
    width: 100%;
}
</style>
